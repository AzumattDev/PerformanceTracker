| `Version`   | `Update Notes`                                                       |
|-------------|----------------------------------------------------------------------|
| 1.0.3       | - Compile against Valheim 0.217.22                                   |
| 1.0.1/1.0.2 | - README updates. Update manifest.json to include link to the GitHub |
| 1.0.0       | - Initial Release                                                    |